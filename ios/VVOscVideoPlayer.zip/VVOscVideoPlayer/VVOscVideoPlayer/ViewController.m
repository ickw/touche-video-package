//
//  ViewController.m
//  VVOscVideoPlayer
//
//  Created by Daiki Ichikawa on 06/04/2015.
//  Copyright (c) 2015 daiki. All rights reserved.
//

#import "ViewController.h"
#import <MediaPlayer/MediaPlayer.h>

@interface ViewController ()
// OSC
@property(nonatomic, retain) OSCManager *oscManager;
@property(nonatomic, retain) OSCInPort *inport;
// MoviePlayer
@property(nonatomic, retain) MPMoviePlayerController *moviePlayerController;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // OSC
    self.oscManager = [[OSCManager alloc] init];
    self.oscManager.delegate = self;
    //self.inport = [self.oscManager createNewInputForPort:8000]; // jp
    //self.inport = [self.oscManager createNewInputForPort:8001]; //en
    self.inport = [self.oscManager createNewInputForPort:8002]; // ch

    
    
    // MoviePlayer
    //NSString* filepath = [[NSBundle mainBundle] pathForResource:@"caption_jp_comp" ofType:@"mov"]; // TODO: use flag to select language
    //NSString* filepath = [[NSBundle mainBundle] pathForResource:@"caption_en_comp" ofType:@"mov"]; // TODO: use flag to select language
    NSString* filepath = [[NSBundle mainBundle] pathForResource:@"caption_ch_comp" ofType:@"mov"]; // TODO: use flag to select language
    
    NSURL *fileURL = [NSURL fileURLWithPath:filepath];
    self.moviePlayerController = [[MPMoviePlayerController alloc] initWithContentURL:fileURL];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(movieFinished:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:self.moviePlayerController];
    
    // hide video controls
    [self.moviePlayerController  setControlStyle:MPMovieControlStyleNone];
    
    [[self.moviePlayerController view] setBackgroundColor:[UIColor grayColor]];
    CGRect bounds = [[UIScreen mainScreen] bounds];
    [self.moviePlayerController.view setFrame:bounds];
    [self.moviePlayerController setScalingMode:MPMovieScalingModeAspectFit];
    [self.view addSubview:self.moviePlayerController.view];
}

- (void) viewWillAppear:(BOOL)animated {
    
    NSLog(@"viewWillAppear");
    [super viewWillAppear:animated];
    
    NSLog(@"OscManager %@", self.oscManager);
    NSLog(@"OSCInPort %@", self.inport);
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

#pragma mark -
#pragma mark VVOSC Recive Delegate
- (void) receivedOSCMessage:(OSCMessage *)m
{
    NSString *address = m.address;
    OSCValue *value = m.value;
    
    if ([address isEqualToString:@"/play"]) {
        NSLog(@"play %d", value.intValue);
        
        [self.moviePlayerController prepareToPlay];
        [self.moviePlayerController play];
        
    } else if ([address isEqualToString:@"/stop"]) {
        NSLog(@"stop %d", value.intValue);
        
        [self.moviePlayerController stop];
    }
}


#pragma mark -
#pragma mark NSNotificationCenter Delegate
-(void) movieFinished:(NSNotification*) notification {
    NSLog(@"Looping Video");
    
    [self.moviePlayerController prepareToPlay];
    [self.moviePlayerController play];
}

@end
