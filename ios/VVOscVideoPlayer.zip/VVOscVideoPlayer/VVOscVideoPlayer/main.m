//
//  main.m
//  VVOscVideoPlayer
//
//  Created by Daiki Ichikawa on 06/04/2015.
//  Copyright (c) 2015 daiki. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
