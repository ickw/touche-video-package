//
//  ViewController.h
//  VVOscVideoPlayer
//
//  Created by Daiki Ichikawa on 06/04/2015.
//  Copyright (c) 2015 daiki. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <VVOSC/VVOSC.h>

@interface ViewController : UIViewController


@end

