//
//  WindowLevel.m
//  ToucheOscReceive
//
//  Created by Daiki Ichikawa on 07/04/2015.
//
//

#include "WindowLevel.h"

#import <Cocoa/Cocoa.h>

void makeScreenSaverWindow()
{
    NSWindow *window = [NSApp mainWindow];
    
    if (window)
    {
        NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
        [window setLevel:NSScreenSaverWindowLevel];
        [pool release];
    }
}


void makeFloatingWindow()
{
    NSWindow *window = [NSApp mainWindow];
    
    if (window)
    {
        NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
        [window setLevel:NSFloatingWindowLevel];
        [pool release];
    }
}


void makeNormalWindow()
{
    NSWindow *window = [NSApp mainWindow];
    
    if (window)
    {
        NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
        [window setLevel:NSNormalWindowLevel];
        [pool release];
    }
}
