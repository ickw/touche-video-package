//
//  GestureEvent.cpp
//  ToucheOscReceive
//
//  Created by Daiki Ichikawa on 26/03/2015.
//
//

#include "GestureEvent.h"

ofEvent <GestureEvent> GestureEvent::event;