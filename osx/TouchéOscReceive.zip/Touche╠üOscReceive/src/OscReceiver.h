//
//  OscReceiver.h
//  ToucheOscReceive
//
//  Created by Daiki Ichikawa on 26/03/2015.
//
//

#ifndef __ToucheOscReceive__OscReceiver__
#define __ToucheOscReceive__OscReceiver__

#include <stdio.h>
#include "ofMain.h"
#include "ofxOsc.h"
#include "GestureRecogniser.h"

#define NUM_MSG_STRINGS 20

class OscReceiver {
    
public:
    void init(int port) {
        
        //
        //gestureRecogniser = *new GestureRecogniser();
        gestureRecogniser.init();
        
        //
        receiver.setup(port);
        receivedGesture = 0;
        
        // for debug
        currentPort = port;
        current_msg_string = 0;
    }
    void update() {
        
//        // hide old messages
//        for(int i = 0; i < NUM_MSG_STRINGS; i++){
//            if(timers[i] < ofGetElapsedTimef()){
//                msg_strings[i] = "";
//            }
//        }
        
        
        while(receiver.hasWaitingMessages()){
        
            ofxOscMessage m;
            receiver.getNextMessage(&m);
            
            if(m.getAddress() == "/gesture"){
                int _gesture = m.getArgAsInt32(0);
                receivedGesture = _gesture;
                
                //
                gestureRecogniser.addGesture(receivedGesture);
                gestureRecogniser.update();
                //
                
            } else{
                string msg_string;
                msg_string = m.getAddress();
                msg_string += ": ";
                for(int i = 0; i < m.getNumArgs(); i++){
                    
                    msg_string += m.getArgTypeName(i);
                    msg_string += ":";
                    
                    if(m.getArgType(i) == OFXOSC_TYPE_INT32){
                        msg_string += ofToString(m.getArgAsInt32(i));
                    }
                    else if(m.getArgType(i) == OFXOSC_TYPE_FLOAT){
                        msg_string += ofToString(m.getArgAsFloat(i));
                    }
                    else if(m.getArgType(i) == OFXOSC_TYPE_STRING){
                        msg_string += m.getArgAsString(i);
                    }
                    else{
                        msg_string += "unknown";
                    }
                }
                
                msg_strings[current_msg_string] = msg_string;
                timers[current_msg_string] = ofGetElapsedTimef() + 5.0f;
                current_msg_string = (current_msg_string + 1) % NUM_MSG_STRINGS;
               
                msg_strings[current_msg_string] = "";
            }
            
        }
    }
    
    void debugDraw() {
        
        gestureRecogniser.debugDraw();
        
        ofDrawBitmapString("PORT: " + ofToString(currentPort), 20, 20);
        ofDrawBitmapString("received gesture: " + ofToString(receivedGesture), 430, 20);
        
//        for(int i = 0; i < NUM_MSG_STRINGS; i++){
//            ofDrawBitmapString(msg_strings[i], 10, 40 + 15 * i);
//        }
    }
    
private:
    
    ofxOscReceiver receiver;
    GestureRecogniser gestureRecogniser;
  
    int currentPort;
    int receivedGesture;
    
    
    // debug
    int current_msg_string;
    string msg_strings[NUM_MSG_STRINGS];
    float timers[NUM_MSG_STRINGS];
    
};


#endif /* defined(__ToucheOscReceive__OscReceiver__) */
