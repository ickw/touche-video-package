//
//  WindowLevel.h
//  ToucheOscReceive
//
//  Created by Daiki Ichikawa on 07/04/2015.
//
//

#include "ofxTweenzor.h"
#pragma once

void makeScreenSaverWindow();
void makeFloatingWindow();
void makeNormalWindow();



