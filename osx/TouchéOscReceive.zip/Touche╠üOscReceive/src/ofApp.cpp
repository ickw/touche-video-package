#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(0);
    ofSetFrameRate(60);
    ofSetVerticalSync(true);
    
    // OSC
    oscReceiver.init(PORT);
    oscSender[0].init(SEND_HOST_0, SEND_PORT_0);
    oscSender[1].init(SEND_HOST_1, SEND_PORT_1);
    
    // Movie
    player.loadMovie("movies/football_comp.mov");
    player.setLoopState(OF_LOOP_NONE);
    player.stop();
    
    // Interaction Timer
    interactionTimer.init();
    
    //
    currentGesture = 0;
    didInteractionStart = false;
    
    // Add event listeners
    ofAddListener(GestureEvent::event, this, &ofApp::startMovie);
    ofAddListener(interactionTimer.movieEndEvent, this, &ofApp::endMovie);
    
    // hide cursor
    ofHideCursor();
//    windowTimer = 0.f;
//    Tweenzor::add(&windowTimer, 0.f, WINDOW_TIMER_DURATION, 0.f, WINDOW_TIMER_DURATION);
//    Tweenzor::addCompleteListener( Tweenzor::getTween(&windowTimer), this, &ofApp::changeWindowLevel);
}

//--------------------------------------------------------------
void ofApp::update(){
    
    oscReceiver.update();
    
    // -------------- VIDEO --------------
    if(didInteractionStart) player.update();
    
    // -------------- Interaction Timer --------------
    interactionTimer.update();

}


//--------------------------------------------------------------
void ofApp::draw(){
    
    if(didInteractionStart) player.draw(0, 0);
    
    //oscReceiver.debugDraw();
}

void ofApp::startMovie(GestureEvent &e) {
    //cout << "geture index: " << e.gestureIndex <<endl;
    
    currentGesture = e.gestureIndex;
    
    
    switch (currentGesture) {
        case 1:
            
            if(!didInteractionStart) {
                cout << "------- Start Movie Event Called -------" <<endl;
                // Send osc
                for (int i=0 ;i< OSC_SEND_TRIAL; i++) {
                    for (int i=0; i<NUM_CLIENTS; i++) {
                        oscSender[i].sendVideoPlay();
                    }
                }
                
                // Play movie
                player.firstFrame();
                player.play();
                
                // Start interaction timer
                interactionTimer.startMovieTimer();
                
                //
                didInteractionStart = true;
            }
            break;
            
        default:
            break;
    }
}

void ofApp::endMovie(float &e) {
    
    cout << "------- End Movie Event Called" <<endl;
    
    // Send Osc
    for (int i=0; i< OSC_SEND_TRIAL; i++) {
        for (int i=0; i<NUM_CLIENTS; i++) {
            oscSender[i].sendVideoStop();
        }
    }
    
    // Stop movie
    player.stop();
    
    //
    didInteractionStart = false;
}


void ofApp::changeWindowLevel(float *timer) {
    cout << "changeWindowLevel" << endl;
    makeScreenSaverWindow();
}

//--------------------------------------------------------------
void ofApp::exit(){
    // Stop clients
    for (int i=0 ;i< OSC_SEND_TRIAL; i++) {
        for (int i=0; i<NUM_CLIENTS; i++) {
            oscSender[i].sendVideoStop();
        }
    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
    if (key == 'h') {
        ofHideCursor();
        makeScreenSaverWindow();
        //makeFloatingWindow();s
    } else if (key == 's') {
        ofShowCursor();
        makeNormalWindow();
    }
    
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){

}
