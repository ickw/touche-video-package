//
//  OscSender.h
//  ToucheOscReceive
//
//  Created by Daiki Ichikawa on 07/04/2015.
//
//

#ifndef ToucheOscReceive_OscSender_h
#define ToucheOscReceive_OscSender_h

#include <stdio.h>
#include "ofMain.h"
#include "ofxOsc.h"

class OscSender {
 
public:
    void init(string host, int port) {
        sender.setup(host, port);
    }
    
    void sendVideoPlay() {
        //cout << "sendVideoPlay" << endl;
        
        ofxOscMessage m;
        m.setAddress("/play");
        m.addIntArg(1);
        sender.sendMessage(m);
    }
    
    void sendVideoStop() {
        //cout << "sendVideoStop" << endl;
        
        ofxOscMessage m;
        m.setAddress("/stop");
        m.addIntArg(1);
        sender.sendMessage(m);
    }
    
private:
    ofxOscSender sender;
    
};


#endif
