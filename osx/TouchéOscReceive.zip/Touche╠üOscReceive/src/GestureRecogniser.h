//
//  GestureRecogniser.h
//  ToucheOscReceive
//
//  Created by Daiki Ichikawa on 26/03/2015.
//
//

#ifndef __ToucheOscReceive__GestureRecogniser__
#define __ToucheOscReceive__GestureRecogniser__

#include <stdio.h>
#include "ofMain.h"
#include "GestureEvent.h"

#define NUM_SMOOTH 10

class GestureRecogniser {
    

public:

//    GestureRecogniser() {
//
//    }
//    
//    ~GestureRecogniser() {
//        
//    }
    
    void init() {
        currentGesture = 0;
        lastGesture = 0;
        isGestureStable = false;
        
        gestureArray.clear();
    }
    
    void addGesture(int gestureIndex) {
        
        gestureArray.push_front(gestureIndex);
        if (gestureArray.size() > NUM_SMOOTH) {
            gestureArray.pop_back();
        }
    }
    
    void update() {
        
        smooth();
        
        if (isGestureStable && didGestureChanged) {
            notifyGestureChanged(currentGesture);
        }
    }
    
    void notifyGestureChanged(int gestureId) {
        cout << "---------- NotifyGestureChanged ----------" <<endl;
        
        static GestureEvent newEvent;
        newEvent.gestureIndex = gestureId;
        ofNotifyEvent(GestureEvent::event, newEvent);
    }
    
    void debugDraw() {
        ofDrawBitmapString(ofToString(currentGesture), 50, 430);
    }
    
private:
    
    void smooth() {
        
        if (gestureArray.size() == NUM_SMOOTH) {
            
            lastGesture = currentGesture;
            
            for (int i=1; i<gestureArray.size(); i++) {
                isGestureStable = gestureArray.at(i-1) == gestureArray.at(i) ? true : false;
                if (!isGestureStable) {
                    //cout << "gesture is not stable " << endl;
                    break;
                }
            }
            
            if (isGestureStable) currentGesture = gestureArray.at(0); // at any index is fine..
            
            if (currentGesture != lastGesture) {
                didGestureChanged = true;
            } else {
                didGestureChanged = false;
            }
        } else {
            //cout << "there's not enought gestures in array" << endl;
        }
        

    }
    
    deque<int> gestureArray;
    int currentGesture, lastGesture;
    bool isGestureStable;
    bool didGestureChanged;
    
};

#endif /* defined(__ToucheOscReceive__GestureRecogniser__) */
