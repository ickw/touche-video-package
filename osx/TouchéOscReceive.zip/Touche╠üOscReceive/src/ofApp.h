#pragma once

#include "ofMain.h"
#include "ofxOsc.h"
#include "OscReceiver.h"
#include "OscSender.h"
#include "GestureEvent.h"
#include "InteractionTimer.h"
#include "WindowLevel.h"


// OSC InPort
#define PORT 8001

// OSC OutPort
#define NUM_CLIENTS 2
#define SEND_HOST_0 "192.168.2.101"
#define SEND_PORT_0 8000
#define SEND_HOST_1 "192.168.2.102"
#define SEND_PORT_1 8002


// OSC NUM_TRIAL
#define OSC_SEND_TRIAL 15

#define WINDOW_TIMER_DURATION 1.f

class ofApp : public ofBaseApp {
	public:

		void setup();
		void update();
		void draw();
        void startMovie(GestureEvent &e);
        void endMovie(float &e);
        void changeWindowLevel(float *timer);

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y);
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
        void exit();

		
        OscReceiver oscReceiver;
        OscSender oscSender[NUM_CLIENTS];
        ofVideoPlayer player;
        InteractionTimer interactionTimer;
    
        int currentGesture;
        bool didInteractionStart;
        float windowTimer;
};
