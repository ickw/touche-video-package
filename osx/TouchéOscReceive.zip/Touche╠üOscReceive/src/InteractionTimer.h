//
//  InteractionTimer.h
//  ToucheOscReceive
//
//  Created by Daiki Ichikawa on 07/04/2015.
//
//

#ifndef ToucheOscReceive_InteractionTimer_h
#define ToucheOscReceive_InteractionTimer_h

#include "ofMain.h"
#include "ofxTweenzor.h"

#define MOVIE_DURATION 20.f

class InteractionTimer {
    
public:
    
    ofEvent <float> movieEndEvent;
    
    void init() {
        Tweenzor::init();
        movieTimer = 0.f;
        
    }
    
    void update() {
        Tweenzor::update(ofGetElapsedTimeMillis());
        
        //cout << "timer: " << movieTimer << endl;
    }
    
    void startMovieTimer() {
        movieTimer = 0.f;
        Tweenzor::add(&movieTimer, 0.f, MOVIE_DURATION, 0.f, MOVIE_DURATION);
        Tweenzor::addCompleteListener( Tweenzor::getTween(&movieTimer), this, &InteractionTimer::movieEnd);
    }
    
    void movieEnd(float *timer) {
        cout << "InteractionTimer:: movieEnd!" <<endl;
        
        Tweenzor::removeTween(&movieTimer);
        Tweenzor::removeCompleteListener(&movieTimer);
        ofNotifyEvent(movieEndEvent, movieTimer, this);
    }
    
private:
    
    float movieTimer;
    
};

#endif
