//
//  gestureEvent.h
//  ToucheOscReceive
//
//  Created by Daiki Ichikawa on 26/03/2015.
//
//

#ifndef ToucheOscReceive_gestureEvent_h
#define ToucheOscReceive_gestureEvent_h

#pragma once
#include "ofMain.h"

class GestureEvent : public ofEventArgs {
public:
    
    int  gestureIndex;

    GestureEvent() {
        gestureIndex = NULL;
    }
    
    static ofEvent <GestureEvent> event;
    
private:

};
#endif
