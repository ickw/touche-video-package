//
//  main.m
//  HideCursor
//
//  Created by Daiki Ichikawa on 08/04/2015.
//  Copyright (c) 2015 daiki. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
