//
//  AppDelegate.m
//  HideCursor
//
//  Created by Daiki Ichikawa on 08/04/2015.
//  Copyright (c) 2015 daiki. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    
    [_window setBackgroundColor:[NSColor blueColor]];
    [_window setMovableByWindowBackground:YES];
    
//    NSPoint mouseWarpLocation = NSMakePoint(1920, 0);
//    //CGEventSourceRef evsrc = CGEventSourceCreate(kCGEventSourceStateCombinedSessionState);
//    //CGEventSourceSetLocalEventsSuppressionInterval(evsrc, 0.0);
//    //CGAssociateMouseAndMouseCursorPosition (0);
//    CGWarpMouseCursorPosition(mouseWarpLocation);
//    //CGAssociateMouseAndMouseCursorPosition (1);
//    
//    //[NSCursor hide];
    
    
}

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    NSPoint mouseWarpLocation = NSMakePoint(1920, 0);
    CGWarpMouseCursorPosition(mouseWarpLocation);
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}



@end
